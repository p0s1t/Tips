package src;


public class Fortune {
	
	public Fortune(){
		
		
		
	}//end constructor

}//end class def
